# PBSM website — free deployment starter

This is a deployable Next.js + Supabase starter for the PBSM member portal. It is **not live yet**. A Vercel URL is created only after you deploy it from your own account.

## Included
- Email/password registration and login
- New member accounts default to `pending`
- Administrator approval and private member list
- Separate Events and Duty Roster pages
- Duty signup/cancellation and capacity checks
- Signup-list access controlled by Supabase Row Level Security
- English / Chinese interface toggle
- Admin and assigned-leader permissions enforced in database policies

## 1. Create the Supabase project
1. Create a project at https://supabase.com/
2. Open **SQL Editor** and run all of `supabase/schema.sql`.
3. In **Project Settings → API**, copy the Project URL and anon/public key.
4. Copy `.env.example` to `.env.local` and fill in those two values.

Do not put a Supabase `service_role` key in the browser or in `NEXT_PUBLIC_...` variables.

## 2. Create the first administrator
1. Run the site locally or deploy it.
2. Register your own account using the email you will use as the PBSM administrator.
3. In Supabase SQL Editor, run this one-time command, replacing the email:
   `update public.profiles set role='admin', status='approved' where email='your-email@example.com';`
4. Sign out and sign in again.

Only this promoted account can approve new members or view the member directory/count.

## 3. Run locally
Install Node.js 20 or newer, then:

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## 4. Deploy to the free Vercel URL
1. Create a GitHub repository and upload this project.
2. Sign in at https://vercel.com/ and import that repository.
3. In Vercel project settings, add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Deploy. Vercel will assign a free `*.vercel.app` URL.
5. In Supabase Authentication URL Configuration, set the Site URL to the deployed Vercel URL and add it to Redirect URLs.

Vercel and Supabase free-plan quotas and terms can change. Check their current limits before relying on them for a school-wide service.

## Important launch checklist
- Have a trusted adult/school IT contact review the project and privacy practices before collecting student information.
- Use a school-approved email policy and collect only information the school needs.
- Enable email confirmation in Supabase if appropriate for your school.
- Set the correct admin email before sharing the public registration link.
- Test with separate admin, leader, and member accounts.
- The leader role must be assigned by the admin. Do not let users self-select admin/leader roles.
- This starter intentionally does not include an admin UI to promote leaders yet; assign a leader role in Supabase SQL Editor after checking the member.
- Add an event-registration feature separately if your school wants members to RSVP to events. Event attendance is intentionally separate from duty signups.

## Security notes
Supabase RLS is enabled on all app tables. The public anon key is intended for browser use; the database policies are the security boundary. Never expose the service-role key. Before real student use, ask the school to review data retention, consent, and account recovery arrangements.
