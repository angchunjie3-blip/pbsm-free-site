-- Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.member_role as enum ('admin','leader','member');
create type public.member_status as enum ('pending','approved','rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  role public.member_role not null default 'member',
  status public.member_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  starts_at timestamptz not null,
  venue text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.duties (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  starts_at timestamptz not null,
  ends_at timestamptz,
  venue text,
  capacity integer not null default 1 check (capacity > 0),
  leader_id uuid references public.profiles(id),
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.duty_signups (
  duty_id uuid not null references public.duties(id) on delete cascade,
  member_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (duty_id, member_id)
);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create or replace function public.is_approved()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from profiles where id=auth.uid() and status='approved') $$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from profiles where id=auth.uid() and role='admin' and status='approved') $$;

create or replace function public.can_manage_duty(duty uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select public.is_admin() or exists(select 1 from duties where id=duty and leader_id=auth.uid()) $$;

-- A member who has signed up for a duty may see the other members on that duty.
create or replace function public.is_duty_member(duty uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from duty_signups where duty_id=duty and member_id=auth.uid()) $$;

-- Allow names to be shown only when the viewer shares a duty with that member,
-- or is the administrator / assigned duty leader.
create or replace function public.can_view_member_profile(target uuid)
returns boolean language sql stable security definer set search_path=public
as $$
  select public.is_admin()
    or exists(
      select 1 from duty_signups mine
      join duty_signups theirs on theirs.duty_id=mine.duty_id
      join duties d on d.id=mine.duty_id
      where mine.member_id=auth.uid()
        and theirs.member_id=target
        and (d.leader_id=auth.uid() or mine.duty_id=theirs.duty_id)
    )
$$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.profiles(id,full_name,email)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),new.email);
  return new;
end;
$$;

create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.events enable row level security;
alter table public.duties enable row level security;
alter table public.duty_signups enable row level security;
alter table public.announcements enable row level security;

-- Profiles: users can read their own; only the one admin can list/manage all profiles.
create policy "profile self read" on public.profiles for select to authenticated using (id=auth.uid() or public.is_admin() or public.can_view_member_profile(id));
create policy "admin update profiles" on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "profile self insert blocked" on public.profiles for insert to authenticated with check (false);

-- Approved members can read event/duty and announcement data.
create policy "approved read events" on public.events for select to authenticated using (public.is_approved());
create policy "admin or leader create events" on public.events for insert to authenticated with check (
  public.is_admin() or (public.is_approved() and created_by=auth.uid() and exists(select 1 from profiles where id=auth.uid() and role='leader'))
);
create policy "admin or creator update events" on public.events for update to authenticated using (
  public.is_admin() or (created_by=auth.uid() and exists(select 1 from profiles where id=auth.uid() and role='leader'))
) with check (public.is_admin() or created_by=auth.uid());
create policy "admin delete events" on public.events for delete to authenticated using (public.is_admin());

create policy "approved read duties" on public.duties for select to authenticated using (public.is_approved());
create policy "admin or leader create duties" on public.duties for insert to authenticated with check (
  public.is_admin() or (public.is_approved() and created_by=auth.uid() and leader_id=auth.uid() and exists(select 1 from profiles where id=auth.uid() and role='leader'))
);
create policy "admin or assigned leader update duties" on public.duties for update to authenticated using (
  public.is_admin() or (leader_id=auth.uid() and public.is_approved())
) with check (public.is_admin() or (leader_id=auth.uid() and public.is_approved()));
create policy "admin delete duties" on public.duties for delete to authenticated using (public.is_admin());

-- Signup list privacy: a member sees rows only for their own signups; admin and assigned duty leader see all.
create policy "signup list visibility" on public.duty_signups for select to authenticated using (
  member_id=auth.uid() or public.can_manage_duty(duty_id) or public.is_duty_member(duty_id)
);
create policy "approved member signup self" on public.duty_signups for insert to authenticated with check (
  member_id=auth.uid() and public.is_approved()
);
create policy "member cancel own signup" on public.duty_signups for delete to authenticated using (
  member_id=auth.uid() or public.can_manage_duty(duty_id)
);

create policy "approved read announcements" on public.announcements for select to authenticated using (public.is_approved());
create policy "admin create announcements" on public.announcements for insert to authenticated with check (public.is_admin() and created_by=auth.uid());
create policy "admin update announcements" on public.announcements for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin delete announcements" on public.announcements for delete to authenticated using (public.is_admin());

-- Capacity guard: prevents two simultaneous signups from exceeding the duty limit.
create or replace function public.check_duty_capacity()
returns trigger language plpgsql security definer set search_path=public
as $$
declare cap integer; current_count integer;
begin
  select capacity into cap from public.duties where id=new.duty_id for update;
  select count(*) into current_count from public.duty_signups where duty_id=new.duty_id;
  if current_count >= cap then raise exception 'This duty is full.'; end if;
  return new;
end;
$$;
create trigger duty_capacity_before_insert before insert on public.duty_signups
for each row execute procedure public.check_duty_capacity();

-- IMPORTANT: after your first account is created, run the one-time admin promotion below.
-- Replace the email with YOUR registration email, then execute separately:
-- update public.profiles set role='admin', status='approved' where email='your-email@example.com';
