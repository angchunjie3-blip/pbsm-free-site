 "use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

type Profile = { id: string; full_name: string; role: "admin"|"leader"|"member"; status: "pending"|"approved"|"rejected" };
type EventRow = { id: string; title: string; description: string|null; starts_at: string; venue: string|null; created_by: string };
type DutyRow = { id: string; title: string; description: string|null; starts_at: string; ends_at: string|null; venue: string|null; capacity: number; leader_id: string|null };

export default function Home() {
  const [user,setUser] = useState<any>(null);
  const [profile,setProfile] = useState<Profile|null>(null);
  const [tab,setTab] = useState("events");
  const [events,setEvents] = useState<EventRow[]>([]);
  const [duties,setDuties] = useState<DutyRow[]>([]);
  const [mySignups,setMySignups] = useState<string[]>([]);
  const [notice,setNotice] = useState("");
  const [lang,setLang] = useState<"en"|"zh">("en");
  const [busy,setBusy] = useState(false);
  const [eventForm,setEventForm] = useState(false);
  const [dutyForm,setDutyForm] = useState(false);
  const [members,setMembers] = useState<any[]>([]);
  const t=(en:string,zh:string)=>lang==="en"?en:zh;

  async function load() {
    if(!supabase) return;
    const {data:{user}}=await supabase.auth.getUser();
    setUser(user);
    if(!user){setProfile(null);return;}
    const {data:p}=await supabase.from("profiles").select("*").eq("id",user.id).maybeSingle();
    setProfile(p as Profile|null);
    const {data:e}=await supabase.from("events").select("*").order("starts_at");
    setEvents((e||[]) as EventRow[]);
    const {data:d}=await supabase.from("duties").select("*").order("starts_at");
    setDuties((d||[]) as DutyRow[]);
    const {data:s}=await supabase.from("duty_signups").select("duty_id").eq("member_id",user.id);
    setMySignups((s||[]).map((x:any)=>x.duty_id));
    if(p?.role==="admin"){
      const {data:m}=await supabase.from("profiles").select("id,full_name,email,status,role").order("created_at");
      setMembers(m||[]);
    }
  }
  useEffect(()=>{load();},[]);
  async function signOut(){await supabase?.auth.signOut();setUser(null);setProfile(null);}
  async function signup(dutyId:string){
    if(!supabase||!user)return;
    setBusy(true);setNotice("");
    const {error}=await supabase.from("duty_signups").insert({duty_id:dutyId,member_id:user.id});
    setNotice(error?error.message:t("Registration could not be completed.","报名未能完成。"));
    if(!error) await load(); setBusy(false);
  }
  async function cancel(dutyId:string){
    if(!supabase||!user)return;
    setBusy(true);
    const {error}=await supabase.from("duty_signups").delete().eq("duty_id",dutyId).eq("member_id",user.id);
    setNotice(error?error.message:t("Registration cancelled.","已取消报名。"));
    await load();setBusy(false);
  }
  async function createRecord(kind:"events"|"duties",form:FormData){
    if(!supabase||!user)return;
    const base={title:String(form.get("title")),description:String(form.get("description")||""),starts_at:new Date(String(form.get("starts_at"))).toISOString(),venue:String(form.get("venue")||""),created_by:user.id};
    const payload=kind==="events"?base:{...base,ends_at:form.get("ends_at")?new Date(String(form.get("ends_at"))).toISOString():null,capacity:Number(form.get("capacity")||1),leader_id:user.id};
    const {error}=await supabase.from(kind).insert(payload);
    setNotice(error?error.message:t("Published successfully.","发布成功。"));
    if(!error){setEventForm(false);setDutyForm(false);await load();}
  }
  async function approve(id:string,status:"approved"|"rejected"){
    const {error}=await supabase!.from("profiles").update({status}).eq("id",id);
    setNotice(error?.message||"Updated.");await load();
  }

  if(!supabase) return <main className="container"><div className="card"><h1 className="text-2xl font-bold text-red-700">PBSM</h1><h2 className="mt-4 text-xl font-semibold">Setup required / 需要完成设置</h2><p className="mt-2 muted">Add your Supabase URL and anon key to the Vercel environment variables. See README.md.</p></div></main>;
  if(!user) return <Auth lang={lang} setLang={setLang} />;
  if(!profile) return <main className="container"><div className="card"><h1 className="text-2xl font-bold">PBSM</h1><p className="mt-3">Your account profile is being prepared. Please refresh in a moment.</p><button className="btn mt-4" onClick={load}>Refresh</button><button className="btn ml-2" onClick={signOut}>Sign out</button></div></main>;
  if(profile.status!=="approved") return <main className="container"><div className="card max-w-xl mx-auto mt-12"><h1 className="text-2xl font-bold text-red-700">PBSM</h1><p className="mt-4 font-semibold">{t("Your registration is pending approval.","你的注册正在等待管理员批准。")}</p><p className="muted mt-2">{t("You can sign in after the administrator approves your account.","管理员批准后即可登录使用。")}</p><button className="btn mt-5" onClick={signOut}>{t("Sign out","退出登录")}</button></div></main>;

  const isAdmin=profile.role==="admin";
  const canManage=profile.role==="admin"||profile.role==="leader";
  const nav=[["events",t("Events","活动")],["duties",t("Duty Roster","站岗报名")],["mine",t("My Schedule","我的站岗")],["ann",t("Announcements","公告")],...(isAdmin?[["members",t("Member Management","会员管理")]]:[])];
  return <main className="container">
    <header className="flex flex-wrap items-center justify-between gap-3 mb-5">
      <div><div className="text-2xl font-bold text-red-700">PBSM</div><div className="muted text-sm">{t("Member Portal","会员平台")} · {profile.full_name}</div></div>
      <div className="flex gap-2"><button className="btn" onClick={()=>setLang(lang==="en"?"zh":"en")}>{lang==="en"?"中文":"English"}</button><button className="btn" onClick={signOut}>{t("Sign out","退出登录")}</button></div>
    </header>
    <nav className="flex flex-wrap gap-2 mb-5">{nav.map(([id,label])=><button key={id} onClick={()=>setTab(id)} className={`btn ${tab===id?"btn-primary":""}`}>{label}</button>)}</nav>
    {notice&&<div className="card mb-4 text-sm">{notice}</div>}
    {tab==="events"&&<section className="space-y-3"><div className="flex justify-between items-center"><h1 className="text-xl font-bold">{t("Events","活动")}</h1>{canManage&&<button className="btn btn-primary" onClick={()=>setEventForm(!eventForm)}>{t("Create event","创建活动")}</button>}</div>
      <p className="muted text-sm">{t("Activity information only. Duty registrations are managed separately.","这里只显示活动资讯。站岗报名在独立页面管理。")}</p>
      {eventForm&&<RecordForm kind="event" onSubmit={f=>createRecord("events",f)} onClose={()=>setEventForm(false)} lang={lang}/>}
      {events.map(e=><article className="card" key={e.id}><h2 className="font-semibold text-lg">{e.title}</h2><p className="muted text-sm mt-1">{new Date(e.starts_at).toLocaleString()} · {e.venue}</p><p className="mt-3">{e.description}</p></article>)}
      {!events.length&&<div className="card muted">{t("No events published yet.","暂时没有活动。")}</div>}</section>}
    {tab==="duties"&&<section className="space-y-3"><div className="flex justify-between items-center"><h1 className="text-xl font-bold">{t("Duty Roster","站岗报名")}</h1>{canManage&&<button className="btn btn-primary" onClick={()=>setDutyForm(!dutyForm)}>{t("Create duty","创建站岗")}</button>}</div>
      <p className="muted text-sm">{t("Sign up for a duty. The full signup list is visible only to approved signups, the duty leader and the administrator.","报名成功后可查看完整名单；站岗负责人和最高管理员也可查看。")}</p>
      {dutyForm&&<RecordForm kind="duty" onSubmit={f=>createRecord("duties",f)} onClose={()=>setDutyForm(false)} lang={lang}/>}
      {duties.map(d=><DutyCard key={d.id} duty={d} userId={user.id} isAdmin={isAdmin} isLeader={d.leader_id===user.id} joined={mySignups.includes(d.id)} busy={busy} onJoin={()=>signup(d.id)} onCancel={()=>cancel(d.id)} lang={lang}/>)}
      {!duties.length&&<div className="card muted">{t("No duties published yet.","暂时没有站岗。")}</div>}</section>}
    {tab==="mine"&&<section className="space-y-3"><h1 className="text-xl font-bold">{t("My Schedule","我的站岗")}</h1>{duties.filter(d=>mySignups.includes(d.id)).map(d=><DutyCard key={d.id} duty={d} userId={user.id} isAdmin={isAdmin} isLeader={d.leader_id===user.id} joined busy={busy} onJoin={()=>signup(d.id)} onCancel={()=>cancel(d.id)} lang={lang}/>)}{!mySignups.length&&<div className="card muted">{t("You have not registered for any duty.","你还没有报名站岗。")}</div>}</section>}
    {tab==="ann"&&<Announcements lang={lang}/>}
    {tab==="members"&&isAdmin&&<section className="space-y-3"><h1 className="text-xl font-bold">{t("Member Management","会员管理")}</h1><div className="card"><b>{t("Approved members","已批准会员")}: {members.filter(m=>m.status==="approved").length}</b></div>{members.map(m=><div className="card flex flex-wrap justify-between gap-3" key={m.id}><div><b>{m.full_name}</b><p className="muted text-sm">{m.email} · {m.status} · {m.role}</p></div>{m.status==="pending"&&<div className="flex gap-2"><button className="btn btn-primary" onClick={()=>approve(m.id,"approved")}>{t("Approve","批准")}</button><button className="btn" onClick={()=>approve(m.id,"rejected")}>{t("Reject","拒绝")}</button></div>}</div>)}</section>}
    <footer className="muted text-xs mt-10 border-t pt-4">PBSM · {t("Member portal","会员平台")}</footer>
  </main>;
}

function Auth({lang,setLang}:{lang:"en"|"zh";setLang:(v:"en"|"zh")=>void}) {
 const [mode,setMode]=useState<"login"|"register">("login");const [msg,setMsg]=useState("");
 const t=(a:string,b:string)=>lang==="en"?a:b;
 async function submit(f:FormData){
  if(!supabase)return;setMsg("");
  const email=String(f.get("email")),password=String(f.get("password"));
  if(mode==="register"){
   const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:String(f.get("name"))}}});
   setMsg(error?.message||t("Registration submitted. Check your email if confirmation is enabled; your account awaits administrator approval.","注册已提交。如启用了邮件确认，请先确认邮箱；之后等待管理员批准。"));
  }else{
   const {error}=await supabase.auth.signInWithPassword({email,password});
   setMsg(error?.message||t("Signed in. Refresh if needed.","登录成功，如未进入请刷新页面。"));
   if(!error)location.reload();
  }
 }
 return <main className="container"><div className="max-w-md mx-auto mt-10 card"><div className="flex justify-between"><h1 className="text-3xl font-bold text-red-700">PBSM</h1><button className="btn" onClick={()=>setLang(lang==="en"?"zh":"en")}>{lang==="en"?"中文":"English"}</button></div><p className="muted mt-1">{t("Member Portal","会员平台")}</p><div className="flex gap-2 mt-6"><button className={`btn flex-1 ${mode==="login"?"btn-primary":""}`} onClick={()=>setMode("login")}>{t("Login","登录")}</button><button className={`btn flex-1 ${mode==="register"?"btn-primary":""}`} onClick={()=>setMode("register")}>{t("Register","注册")}</button></div><form action={async f=>submit(f)} className="space-y-3 mt-5">{mode==="register"&&<input className="field" name="name" placeholder={t("Full name","姓名")} required/>}<input className="field" name="email" type="email" placeholder="Email" required/><input className="field" name="password" type="password" minLength={8} placeholder={t("Password (min. 8 characters)","密码（至少 8 个字符）")} required/><button className="btn btn-primary w-full">{mode==="login"?t("Login","登录"):t("Create account","创建账号")}</button></form>{msg&&<p className="text-sm mt-4">{msg}</p>}<p className="muted text-xs mt-5">{t("New accounts require administrator approval.","新注册账号必须经过管理员批准。")}</p></div></main>;
}

function RecordForm({kind,onSubmit,onClose,lang}:{kind:"event"|"duty";onSubmit:(f:FormData)=>void;onClose:()=>void;lang:"en"|"zh"}) {
 const t=(a:string,b:string)=>lang==="en"?a:b;
 return <form action={onSubmit} className="card space-y-3"><h2 className="font-semibold">{kind==="event"?t("New event","新活动"):t("New duty","新站岗")}</h2><input className="field" name="title" placeholder={t("Title","名称")} required/><textarea className="field" name="description" placeholder={t("Description","介绍")}/><input className="field" name="starts_at" type="datetime-local" required/><input className="field" name="venue" placeholder={t("Venue","地点")}/>{kind==="duty"&&<><input className="field" name="ends_at" type="datetime-local"/><label className="text-sm">{t("Capacity","名额")}<input className="field mt-1" name="capacity" type="number" min="1" defaultValue="10"/></label></>}<div className="flex gap-2"><button className="btn btn-primary">{t("Publish","发布")}</button><button type="button" className="btn" onClick={onClose}>{t("Cancel","取消")}</button></div></form>;
}

function DutyCard({duty,userId,isAdmin,isLeader,joined,busy,onJoin,onCancel,lang}:{duty:DutyRow;userId:string;isAdmin:boolean;isLeader:boolean;joined:boolean;busy:boolean;onJoin:()=>void;onCancel:()=>void;lang:"en"|"zh"}) {
 const [expanded,setExpanded]=useState(false);const [names,setNames]=useState<any[]>([]);const [count,setCount]=useState(0);const [err,setErr]=useState("");
 const t=(a:string,b:string)=>lang==="en"?a:b;
 async function reveal(){
  if(!supabase)return;setExpanded(!expanded);if(expanded)return;
  const {count:c}=await supabase.from("duty_signups").select("*",{count:"exact",head:true}).eq("duty_id",duty.id);setCount(c||0);
  const {data,error}=await supabase.from("duty_signups").select("member_id, profiles(full_name)").eq("duty_id",duty.id);
  if(error)setErr(t("You must sign up first to view the list.","你必须先报名才能查看名单。"));
  else setNames(data||[]);
 }
 return <article className="card"><div className="flex justify-between gap-2"><h2 className="font-semibold text-lg">{duty.title}</h2><span className="text-xs rounded-full bg-red-50 text-red-800 px-3 py-1">{t("Duty","站岗")}</span></div><p className="muted text-sm mt-2">{new Date(duty.starts_at).toLocaleString()} · {duty.venue}</p><p className="mt-2">{duty.description}</p><p className="muted text-sm mt-2">{t("Capacity","名额")}: {count||"—"} / {duty.capacity}</p><div className="flex flex-wrap gap-2 mt-4">{joined?<button disabled={busy} className="btn" onClick={onCancel}>{t("Cancel signup","取消报名")}</button>:<button disabled={busy} className="btn btn-primary" onClick={onJoin}>{t("Sign up","报名")}</button>}<button className="btn" onClick={reveal}>{expanded?t("Hide list","收起名单"):t("View signup list","查看报名名单")}</button></div>{expanded&&<div className="mt-4 border-t pt-3"><b>{t("Signup list","报名名单")}</b>{err&&<p className="text-sm mt-2 text-red-700">{err}</p>}{names.map((n:any)=><p className="text-sm mt-1" key={n.member_id}>{n.profiles?.full_name||t("Member","会员")}</p>)}{!err&&!names.length&&<p className="muted text-sm mt-2">{t("No signups yet.","还没有人报名。")}</p>}</div>}</article>;
}

function Announcements({lang}:{lang:"en"|"zh"}) {
 const [items,setItems]=useState<any[]>([]);
 useEffect(()=>{supabase?.from("announcements").select("*").order("created_at",{ascending:false}).then(({data})=>setItems(data||[]));},[]);
 return <section className="space-y-3"><h1 className="text-xl font-bold">{lang==="en"?"Announcements":"公告"}</h1>{items.map(a=><article className="card" key={a.id}><b>{a.title}</b><p className="mt-2">{a.body}</p><p className="muted text-xs mt-2">{new Date(a.created_at).toLocaleString()}</p></article>)}{!items.length&&<div className="card muted">{lang==="en"?"No announcements yet.":"暂时没有公告。"}</div>}</section>;
}
