import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "PBSM | Member Portal",
  description: "PBSM activities and duty roster portal"
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
